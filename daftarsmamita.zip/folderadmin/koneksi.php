<?php
$dbhost = "localhost";

$dbuser = "root";
$dbpassword = "";
$database = "db_ppdb20sma";


//$dbuser = "smamtasc_ppdb";
//$dbpassword = "Smamita18";
//$database = "smamtasc_ppdb";

$db = @mysql_connect($dbhost, $dbuser, $dbpassword) or die("Connection Error: " . @mysql_error());
@mysql_select_db($database) or die("Tidak Terkoneksi Dengan Database.");
?>
