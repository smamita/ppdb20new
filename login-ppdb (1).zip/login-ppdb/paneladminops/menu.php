<div class="row">
    <div class="col-lg-12">
        <div class="navbar navbar-default">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">PPDB SMAM1TA 2019/2020</a>
            </div>
            <div class="navbar-collapse collapse navbar-responsive-collapse">
                <ul class="nav navbar-nav">
                    <li><a href="list.html">Beranda</a></li>
                    <li><a href="approve.html">Approve</a></li>
                    <!-- <li><a href="alur-pendaftaran.html">Alur Pendaftaran</a></li> -->
                    <!-- <li><a href="panduan.html">Panduan</a></li> -->
                    <li><a href="du.html">Daftar Ulang</a></li>
                    <!-- <li><a href="user.html">User</a></li> -->
                    <li><a href="logout.html">Logout</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
