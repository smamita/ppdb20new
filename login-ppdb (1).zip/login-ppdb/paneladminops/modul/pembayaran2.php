<style type='text/css'>
.judul_ppdb{
	font-size:15pt;
	text-align:center;
	font-weight:bold;
}
.ppdb1{  font-weight:bold;line-height:35px;margin-top:20px;}
.ppdb2{ margin-left:30px;line-height:25px;text-indent:-18px; }
.ppdb3{ margin-left:50px;line-height:25px;text-indent:-18px; }
.ppdb4{ margin-left:70px;line-height:25px;text-indent:-18px; }
.tabelppdb th{ color:green;background:yellow; }
</style>
<body>
<p><strong>Rincian Keuangan dan Ketentuan Pembayaran Peserta Didik  Baru</strong> <br />
<div class='ppdb2'>1. Rincian Keuangan DPP</div>

	<table border='1' style='border-collapse:collapse;border:1px solid #000;width:95%;margin-left:35px;'>
		<tr>
			<th style='font-family:arial;font-size:8pt;text-align:center;'>No</th>
			<th style='font-family:arial;font-size:8pt;text-align:center;'>Jenis Keuangan</th>
			<th style='font-family:arial;font-size:8pt;text-align:center;'>Gelombang 1 MUHAMMADIYAH</th>
			<th style='font-family:arial;font-size:8pt;text-align:center;'>Gelombang 1 NON MUHAMMADIYAH</th>
			<th style='font-family:arial;font-size:8pt;text-align:center;'>Gelombang 2 MUHAMMADIYAH</th>
			<th style='font-family:arial;font-size:8pt;text-align:center;'>Gelombang 2 NON MUHAMMADIYAH</th>
		</tr>
		<tr>
			<td align="center">1</td>
			<td>DPP</td>
			<td>Rp. 3.000.000,&#45;</td>
			<td>Rp. 3.500.000,&#45;</td>
			<td>Rp. 3.500.000,&#45;</td>
			<td>Rp. 4.000.000,&#45;</td>
		</tr>
	</table>

<div class='ppdb2'>2.  Rincian Keuangan Non-DPP</div>
<table border='1' style='border-collapse:collapse;border:1px solid #000;width:95%;margin-left:35px;'>
	<tr>
		<th style='font-family:arial;font-size:8pt;text-align:center;'>No</th>
		<th style='font-family:arial;font-size:8pt;text-align:center;'>Jenis Keuangan</th>
		<th style='font-family:arial;font-size:8pt;text-align:center;'>Gelombang 1 MUHAMMADIYAH</th>
		<th style='font-family:arial;font-size:8pt;text-align:center;'>Gelombang 1 NON MUHAMMADIYAH</th>
		<th style='font-family:arial;font-size:8pt;text-align:center;'>Gelombang 2 MUHAMMADIYAH</th>
		<th style='font-family:arial;font-size:8pt;text-align:center;'>Gelombang 2 NON MUHAMMADIYAH</th>
	</tr>
	<tr>
		<td align="center">1</td>
		<td>SPP bulan Juli 2018</td>
		<td style='text-align:right;'>Rp.    400.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    400.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    400.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    400.000,&#45;&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td align="center">2</td>
		<td>Kegiatan UTS & UAS (1 Tahun)</td>
		<td style='text-align:right;'>Rp.    350.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    350.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    350.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    350.000,&#45;&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td align="center">3</td>
		<td>Pengembangan Vokasi Siswa (1 Tahun)</td>
		<td style='text-align:right;'>Rp.    200.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    200.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    200.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    200.000,&#45;&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td align="center">4</td>
		<td>Kegiatan Organisasi Siswa (1 tahun)</td>
		<td style='text-align:right;'>Rp.    150.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    150.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    150.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    150.000,&#45;&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td align="center">5</td>
		<td>Uang Infaq Siswa (UIS)</td>
		<td style='text-align:right;'>Rp.    200.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    200.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    200.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    200.000,&#45;&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td align="center">6</td>
		<td>IURAN MKKS (1 Tahun)</td>
		<td style='text-align:right;'>Rp.      30.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.      30.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.      30.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.      30.000,&#45;&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td align="center">7</td>
		<td>Darul Arqam</td>
		<td style='text-align:right;'>Rp.    50.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    50.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    50.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    50.000,&#45;&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td align="center">8</td>
		<td>Asuransi & Kartu Pelajar</td>
		<td style='text-align:right;'>Rp.    50.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    50.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    50.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    50.000,&#45;&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td align="center">9</td>
		<td>Leadership Exercise</td>
		<td style='text-align:right;'>Rp.    325.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    325.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    325.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    325.000,&#45;&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td align="center">10</td>
		<td>Student Research</td>
		<td style='text-align:right;'>Rp.    300.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    300.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    300.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    300.000,&#45;&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td align="center">11</td>
		<td>Biaya Laporan Hasil Belajar Siswa</td>
		<td style='text-align:right;'>Rp.    60.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    60.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    60.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    60.000,&#45;&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td align="center">12</td>
		<td>FORTASI</td>
		<td style='text-align:right;'>Rp.    55.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    55.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    55.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    55.000,&#45;&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td align="center">13</td>
		<td>Biaya Psiko Tes</td>
		<td style='text-align:right;'>Rp.    60.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    60.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    60.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    60.000,&#45;&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td align="center">14</td>
		<td>Belajar Berqurban</td>
		<td style='text-align:right;'>Rp.    100.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    100.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    100.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    100.000,&#45;&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td align="center">15</td>
		<td>Kalender</td>
		<td style='text-align:right;'>Rp.    30.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    30.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    30.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    30.000,&#45;&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td align="center">16</td>
		<td>Kegiatan Wisuda dan Pentas Seni</td>
		<td style='text-align:right;'>Rp.    250.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    250.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    250.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    250.000,&#45;&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td align="center">17</td>
		<td>Buku Pribadi</td>
		<td style='text-align:right;'>Rp.    15.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    15.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    15.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    15.000,&#45;&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td align="center">18</td>
		<td>Seragam Olahraga</td>
		<td style='text-align:right;'>Rp.    100.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    100.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    100.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    100.000,&#45;&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td align="center">19</td>
		<td>Seragam Sekolah</td>
		<td style='text-align:right;'>Rp.    1.200.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    1.200.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    1.200.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    1.200.000,&#45;&nbsp;&nbsp;</td>
	</tr>

	<tr>
		<td colspan='2' align="center">Jumlah</td>
		<td style='text-align:right;'><b>Rp.    6.925.000,&#45;&nbsp;&nbsp;</b></td>
		<td style='text-align:right;'><b>Rp.    7.425.000,&#45;&nbsp;&nbsp;</b></td>
		<td style='text-align:right;'><b>Rp.    7.425.000,&#45;&nbsp;&nbsp;</b></td>
		<td style='text-align:right;'><b>Rp.    7.925.000,&#45;&nbsp;&nbsp;</b></td>
	</tr>
	<tr>
		<td align="center">19</td>
		<td>Student Exchange Singapore *</td>
		<td style='text-align:right;'>Rp.    7.000.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    7.000.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    7.000.000,&#45;&nbsp;&nbsp;</td>
		<td style='text-align:right;'>Rp.    7.000.000,&#45;&nbsp;&nbsp;</td>
	</tr>
</table><br>
<div class='ppdb2'>* Student Exchange Singapore Bagi Siswa yang Berminat</div><br>
<div class='ppdb2'>3. Ketentuan Pembayaran Keuangan Peserta Didik Baru</div>
	<div class='ppdb3'>a.  Pada saat Daftar Ulang (Registrasi) Peserta Didik Baru sudah membayar :</div>
		<div class='ppdb4'>1). 50% Uang DPP</div>
		<div class='ppdb4'>2). Membayar keuangan non DPP.</div>
	<div class='ppdb3'>b.  Peserta Didik Baru yang sudah melakukan pendaftaran (Registrasi) kemudian mengundurkan diri, maka keuangan yang telah dibayarkan tidak ditarik kembali</div>
		<div class='ppdb4'>1). Pembayaran ke-2 (25%) : Sebelum UTS Semester Ganjil tahun 2018</div>
		<div class='ppdb4'>2). Pembayaran ke-3 (25%) : Sebelum UAS Semester Ganjil tahun 2018</div>
</body>
</html>
