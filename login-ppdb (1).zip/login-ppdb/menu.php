<div class="mobile-menu-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="mobile-menu">
                        <nav id="dropdown">
                            <ul class="mobile-menu-nav">
                                <li><a data-toggle="collapse" data-target="#Charts" href="index.php">Beranda</a>
                                </li>
                                <li><a data-toggle="collapse" data-target="#demoevent" href="alur.html">Alur</a>
                                </li>
                                <li><a data-toggle="collapse" data-target="#democrou" href="formulir.html">Pendaftaran Online</a>
                                </li>
                                <li><a data-toggle="collapse" data-target="#demolibra" href="login.html">Login</a>
                                </li>
                                <li><a data-toggle="collapse" data-target="#demodepart" href="cetak-ulang.html">Cetak Ulang Akun</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>


<div class="main-menu-area mg-tb-40">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <ul class="nav nav-tabs notika-menu-wrap menu-it-icon-pro">
                    <li><a href="index.php"><i class="notika-icon notika-house"></i> Beranda</a>
                    </li>
                    <li><a href="alur.html"><i class="notika-icon notika-mail"></i> Alur</a>
                    </li>
                    <li><a href="formulir.html"><i class="notika-icon notika-edit"></i> Pendaftaran Online</a>
                    </li>
                    <li><a href="login.html"><i class="notika-icon notika-bar-chart"></i> Login</a>
                    </li>
                    <li><a href="cetak-ulang.html"><i class="notika-icon notika-windows"></i> Cetak Ulang Akun</a>
                    </li>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
